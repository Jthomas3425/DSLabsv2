class Ride():
    pass