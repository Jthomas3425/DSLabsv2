class Passenger():
    pass