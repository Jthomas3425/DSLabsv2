INSERT INTO dogs (name, age, gender, breed, temperament, hungry) VALUES
("Snoopy", 3, "M", "beagle", "friendly", 1),
("McGruff", 10, "M", "bloodhound", "aware", 0),
("Scooby", 6, "M", "great dane", "hungry", 1),
("Little Ann", 5, "F", "coonhound", "loyal", 0),
("Pickles", 13, "F", "black lab", "mischievous", 1),
("Clifford", 4, "M", "big red", "smiley", 1),
("Lassie", 7, "F", "collie", "loving", 1),
("Snowy", 8, "F", "fox terrier", "adventurous", 0),
(NULL, 4, "M", "golden retriever", "playful", 1);
