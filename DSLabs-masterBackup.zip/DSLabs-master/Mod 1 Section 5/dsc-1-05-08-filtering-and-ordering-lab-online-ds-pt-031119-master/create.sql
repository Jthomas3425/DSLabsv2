CREATE TABLE dogs (id INTEGER PRIMARY KEY, name TEXT, age INTEGER, gender CHAR(1), breed TEXT, temperament TEXT, hungry BOOLEAN);
